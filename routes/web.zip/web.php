<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::post('/postLoginUser', 'testController@postt');
Route::get('/', function () {    return view('welcome'); });
Route::get('/main', function () {    return view('welcome'); });
Route::get('/realtime', function ()   {    return view('welcome'); });
Route::get('/analysis', function ()   {    return view('welcome'); });
Route::get('/management', function () {    return view('welcome'); });



Route::get('realtime/list/{local}/{subLocal}', 'realtimeController@vdList');


// <----------- analysis ----------->
Route::get('analysis/search/{place}', 'analysisController@placeSearch'); // 학교, 병원, 회사, 공원 등의 전체 판매량(판매량이 높은순으로 정렬 됨)
Route::get('analysis/getMonthlySalesVolume/{place}', 'analysisController@getMonthlySalesVolume'); // 학교, 병원, 회사, 공원 등의 월별 판매량 
Route::get('analysis/salesVolumeByTime/{place}', 'analysisController@salesVolumeByTime'); // 학교, 병원, 회사, 공원 등의 시간별 판매량
Route::get('analysis/lineChange/{vd_id}', 'analysisController@lineChange'); // 라인 변경이 필요한 자판기의 자판기 정보(판매되고 있는 음료) 조회
Route::get('analysis/setLineChangeNote/{vd_id}/{ChangLine}/{changeDrink}', 'analysisController@setLineChangeNote');  // 자판기의 음료 변경 지시한 것을 작업지시서에 추가 




// <----------- management ----------->
Route::get('management/getSP', 'managementController@getSP'); // 보충기사 리스트 요청
Route::get('jobOrder/{spName}', 'jobOrderController@getJobOrder'); // 보충기사별 작업지시서 요청

Route::get('realtime/getVdStock/{vd_id}', 'realtimeController@getVdStock');
Route::get('realtime/coinStock/{vd_id}', 'realtimeController@coinStock');
Route::get('realtime/list/{local}/{subLocal}', 'realtimeController@vdList');

